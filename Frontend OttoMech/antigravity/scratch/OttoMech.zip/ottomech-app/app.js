/**
 * OttoMech Roadside Assistance - Application Engine
 * Pure JS State Machine, Canvas Map Simulator, and Uber UX Flow
 */

// Application State
const appState = {
  currentScreen: 'landing',
  userRole: 'user', // 'user' or 'mechanic'
  userInfo: {
    firstName: '',
    lastName: '',
    phone: '',
    email: ''
  },
  selectedIssue: 'Flat tyre',
  uploadedPhoto: null,
  isOffline: false,
  detectedLocation: 'Gomti Nagar, Lucknow',
  userCoords: { x: 180, y: 220 }, // Center-ish coordinate on our canvas map
  seededMechanics: [
    {
      id: 'mech-1',
      name: 'Deepak Singh',
      garage: 'Lucknow Precision Garages',
      rating: 4.8,
      distance: 0.8,
      eta: 3,
      mri: 98,
      vehicle: 'Royal Enfield Bullet - UP 32 AB 1234',
      avatar: 'DS',
      startCoords: { x: 50, y: 120 }
    },
    {
      id: 'mech-2',
      name: 'Rahul Bajpai',
      garage: 'Bajpai Auto Tech',
      rating: 4.6,
      distance: 1.4,
      eta: 5,
      mri: 94,
      vehicle: 'Hero Splendor - UP 32 XY 5678',
      avatar: 'RB',
      startCoords: { x: 320, y: 80 }
    },
    {
      id: 'mech-3',
      name: 'Amit Verma',
      garage: 'Gomti Motor Works',
      rating: 4.9,
      distance: 1.9,
      eta: 7,
      mri: 97,
      vehicle: 'Suzuki Access - UP 32 CZ 9012',
      avatar: 'AV',
      startCoords: { x: 120, y: 380 }
    },
    {
      id: 'mech-4',
      name: 'Vinay Kumar',
      garage: 'Lalbagh Multi-Brand',
      rating: 4.5,
      distance: 2.3,
      eta: 9,
      mri: 91,
      vehicle: 'TVS Jupiter - UP 32 DM 3456',
      avatar: 'VK',
      startCoords: { x: 350, y: 290 }
    }
  ],
  selectedMechanic: null,
  activeRating: 5,
  activeTip: 50,
  chatMessages: [
    { sender: 'mechanic', text: 'Hello, I have accepted your request. Please share your landmarks.', time: '10:14 AM' }
  ],
  paymentMethod: 'UPI',
  jobId: '#JOB-7643',
  warrantyId: 'OM-2026-9871'
};

// ----------------------------------------------------
// DYNAMIC SVG LOGO GENERATOR
// ----------------------------------------------------
// Inject Logo Images on load
window.addEventListener('DOMContentLoaded', () => {
  // Inject logos
  document.getElementById('logo-landing').innerHTML = `<img src="logo.jpg" alt="OttoMech Logo" style="width: 100%; height: 100%; object-fit: contain; filter: drop-shadow(0 4px 10px rgba(109, 40, 217, 0.1));">`;
  document.getElementById('logo-signup').innerHTML = `<img src="logo.jpg" alt="OttoMech Logo" style="width: 100%; height: 100%; object-fit: contain;">`;
  document.getElementById('logo-otp').innerHTML = `<img src="logo.jpg" alt="OttoMech Logo" style="width: 100%; height: 100%; object-fit: contain;">`;
  document.getElementById('logo-payment').innerHTML = `<img src="logo.jpg" alt="OttoMech Logo" style="width: 100%; height: 100%; object-fit: contain;">`;
  document.getElementById('logo-rating').innerHTML = `<img src="logo.jpg" alt="OttoMech Logo" style="width: 100%; height: 100%; object-fit: contain;">`;
  document.getElementById('logo-mechanic-home').innerHTML = `<img src="logo.jpg" alt="OttoMech Logo" style="width: 100%; height: 100%; object-fit: contain;">`;
  document.getElementById('logo-mechanic-qr').innerHTML = `<img src="logo.jpg" alt="OttoMech Logo" style="width: 100%; height: 100%; object-fit: contain;">`;
  
  // Start dynamic clock in device status bar
  updateDeviceClock();
  setInterval(updateDeviceClock, 60000);

  // Focus setup for OTP inputs
  setupOTPInputFocus();

  // Setup Canvas Map
  initCanvasMap('map-canvas');

  // Network Offline Toggle listener
  setupOfflineSimulator();
});

// Device status bar clock
function updateDeviceClock() {
  const now = new Date();
  let hours = now.getHours();
  let minutes = now.getMinutes();
  hours = hours < 10 ? '0' + hours : hours;
  minutes = minutes < 10 ? '0' + minutes : minutes;
  document.getElementById('status-time').innerText = `${hours}:${minutes}`;
}

// ----------------------------------------------------
// NAVIGATION SYSTEM
// ----------------------------------------------------
function goToScreen(screenId) {
  // Hide all screens
  const screens = document.querySelectorAll('.screen');
  screens.forEach(s => {
    s.classList.remove('active', 'screen-slide-in');
  });

  // Show target screen
  const target = document.getElementById(`screen-${screenId}`);
  if (target) {
    target.classList.add('active', 'screen-slide-in');
    appState.currentScreen = screenId;
    
    // Custom logic on entering screens
    if (screenId === 'home') {
      // Re-trigger map sizing and draw
      setTimeout(() => initCanvasMap('map-canvas'), 100);
    } else if (screenId === 'tracking') {
      startTrackingSimulation();
    } else if (screenId === 'otp') {
      startOTPTimer();
    } else if (screenId === 'mechanic-home') {
      // Update mechanic profile labels from signup
      document.getElementById('mech-home-name').innerText = `${appState.userInfo.firstName} ${appState.userInfo.lastName}`.trim() || 'Deepak Singh';
      document.getElementById('mech-home-avatar').innerText = ((appState.userInfo.firstName[0] || 'D') + (appState.userInfo.lastName[0] || 'S')).toUpperCase();
      
      const garageTag = document.getElementById('mech-home-garage-display');
      const garageName = document.getElementById('mech-home-garage-name');
      if (appState.mechanicInfo && appState.mechanicInfo.garageName) {
        garageTag.classList.remove('hidden');
        garageName.innerText = appState.mechanicInfo.garageName;
      } else {
        garageTag.classList.add('hidden');
      }
    }
  }
}

function selectRole(role) {
  appState.userRole = role;
  
  // Toggle UI cards
  document.querySelectorAll('.role-card').forEach(card => card.classList.remove('active'));
  if (role === 'user') {
    document.querySelector('.user-card').classList.add('active');
    document.getElementById('mechanic-fields').classList.add('hidden');
    document.querySelector('.step-indicator').innerText = 'Step 1 of 2 — User Info';
  } else {
    document.querySelector('.mechanic-card').classList.add('active');
    document.getElementById('mechanic-fields').classList.remove('hidden');
    document.querySelector('.step-indicator').innerText = 'Step 1 of 2 — Mechanic Info';
  }
}

// ----------------------------------------------------
// SIGN UP & OTP LOGIC
// ----------------------------------------------------
function handleSignup(event) {
  event.preventDefault();
  
  appState.userInfo.firstName = document.getElementById('first-name').value;
  appState.userInfo.lastName = document.getElementById('last-name').value;
  appState.userInfo.phone = document.getElementById('phone').value;
  appState.userInfo.email = document.getElementById('email').value || `${appState.userInfo.firstName.toLowerCase()}@email.com`;
  
  // Save mechanic specifics
  if (appState.userRole === 'mechanic') {
    const isGarage = document.querySelector('input[name="affiliation"]:checked').value === 'garage';
    appState.mechanicInfo = {
      isGarage: isGarage,
      garageName: isGarage ? document.getElementById('garage-name').value : '',
      garageAddress: isGarage ? document.getElementById('garage-address').value : ''
    };
  }
  
  // Populate OTP subtitle email
  document.getElementById('display-email').innerText = appState.userInfo.email;
  
  // Go to OTP Screen
  goToScreen('otp');
  showToast(`Mock SMS Sent to +91 ${appState.userInfo.phone}`);
}

function setupOTPInputFocus() {
  const boxes = document.querySelectorAll('.otp-box');
  boxes.forEach((box, idx) => {
    box.addEventListener('input', (e) => {
      if (box.value.length === 1 && idx < boxes.length - 1) {
        boxes[idx + 1].focus();
      }
    });

    box.addEventListener('keydown', (e) => {
      if (e.key === 'Backspace' && box.value.length === 0 && idx > 0) {
        boxes[idx - 1].focus();
      }
    });
  });
}

let otpInterval = null;
function startOTPTimer() {
  if (otpInterval) clearInterval(otpInterval);
  let duration = 120; // 2 minutes
  const display = document.getElementById('otp-timer');
  
  otpInterval = setInterval(() => {
    let minutes = Math.floor(duration / 60);
    let seconds = duration % 60;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    seconds = seconds < 10 ? '0' + seconds : seconds;
    display.innerText = `${minutes}:${seconds}`;
    
    if (--duration < 0) {
      clearInterval(otpInterval);
      display.innerText = 'Resend OTP';
      display.style.cursor = 'pointer';
      display.onclick = () => {
        startOTPTimer();
        showToast('New verification code sent');
      };
    }
  }, 1000);
}

function verifyOTP() {
  // Grab otp values
  const boxes = document.querySelectorAll('.otp-box');
  let filled = true;
  boxes.forEach(b => { if (!b.value) filled = false; });
  
  if (!filled) {
    showToast('Please enter the full 6-digit code');
    return;
  }
  
  clearInterval(otpInterval);
  showToast('Phone verified successfully');
  
  if (appState.userRole === 'mechanic') {
    goToScreen('mechanic-home');
  } else {
    goToScreen('home');
  }
}

// ----------------------------------------------------
// CANVAS MAP SIMULATOR (Lucknow Theme)
// ----------------------------------------------------
const mapThemes = {
  land: '#F5F3FF', // Very light violet matching app theme
  water: '#DDD6FE', // Soft violet-blue for water
  park: '#EDE9FE', // Light lilac for green zones
  roads: '#FFFFFF', // Clean white roads
  labels: '#5B21B6' // Deep violet text labels
};

function initCanvasMap(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);
  
  // Render Map elements
  drawMapBase(ctx, rect.width, rect.height);
}

function drawMapBase(ctx, width, height) {
  // 1. Draw Land Base Background
  ctx.fillStyle = mapThemes.land;
  ctx.fillRect(0, 0, width, height);
  
  // 2. Draw Parks (lilac blocks)
  ctx.fillStyle = mapThemes.park;
  ctx.fillRect(30, 40, 110, 80); // Janeshwar Park Mock
  ctx.fillRect(250, 310, 120, 100); // Lohia Park Mock
  
  // Park Label
  ctx.fillStyle = '#7C3AED';
  ctx.font = '800 8px "Plus Jakarta Sans"';
  ctx.fillText('JANESHWAR PARK', 45, 80);
  ctx.fillText('LOHIA PARK', 285, 360);

  // 3. Draw Water (Gomti River - curved path)
  ctx.strokeStyle = mapThemes.water;
  ctx.lineWidth = 32;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(-20, 280);
  ctx.bezierCurveTo(120, 270, 200, 180, 420, 160);
  ctx.stroke();
  
  // River label
  ctx.fillStyle = '#6D28D9';
  ctx.font = 'italic 750 9px "Plus Jakarta Sans"';
  ctx.fillText('Gomti River', 160, 215);

  // 4. Draw Roads (grid system)
  ctx.strokeStyle = mapThemes.roads;
  ctx.lineCap = 'round';
  ctx.lineJoin = 'round';
  
  // Main Expressway / Faizabad Road
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.moveTo(-10, 150);
  ctx.lineTo(430, 150);
  ctx.stroke();

  // Secondary Roads
  ctx.lineWidth = 8;
  ctx.beginPath();
  // Gomti Nagar vertical axis
  ctx.moveTo(180, -10);
  ctx.lineTo(180, 450);
  // Hazratganj connector diagonal
  ctx.moveTo(50, 450);
  ctx.lineTo(350, -10);
  // Lower connector
  ctx.moveTo(-10, 350);
  ctx.lineTo(430, 350);
  ctx.stroke();

  // Road center line markings (dashed violet highlights)
  ctx.strokeStyle = '#DDD6FE';
  ctx.lineWidth = 1.5;
  ctx.setLineDash([5, 5]);
  
  ctx.beginPath();
  ctx.moveTo(-10, 150);
  ctx.lineTo(430, 150);
  ctx.moveTo(180, -10);
  ctx.lineTo(180, 450);
  ctx.stroke();
  ctx.setLineDash([]); // Reset dash

  // 5. Road Labels
  ctx.fillStyle = '#7C3AED';
  ctx.font = '800 7px "Plus Jakarta Sans"';
  ctx.fillText('FAIZABAD ROAD', 20, 144);
  ctx.fillText('GOMTI NAGAR BYPASS', 190, 80);

  // 6. Draw User Location Pin (pulsing purple dot)
  const user = appState.userCoords;
  ctx.fillStyle = 'rgba(109, 40, 217, 0.2)';
  ctx.beginPath();
  ctx.arc(user.x, user.y, 22, 0, Math.PI * 2);
  ctx.fill();
  
  ctx.fillStyle = '#6D28D9';
  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(user.x, user.y, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // 7. Draw Standby Mechanic Pins (Violet gears)
  appState.seededMechanics.forEach(mech => {
    drawMechanicPin(ctx, mech.startCoords.x, mech.startCoords.y, mech.avatar);
  });
}

function drawMechanicPin(ctx, x, y, initials) {
  // Outer gear-like dot
  ctx.fillStyle = '#8B5CF6';
  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 2;
  
  ctx.beginPath();
  ctx.arc(x, y, 14, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  // Draw initials in center
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '800 8px "Plus Jakarta Sans"';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(initials, x, y);
}

function reLocateUser() {
  showToast('Locating GPS position...');
  // Simulating relocation check
  navigator.geolocation.getCurrentPosition(
    (pos) => {
      appState.detectedLocation = 'Indira Nagar Area, Lucknow';
      document.getElementById('current-location-val').innerText = appState.detectedLocation;
      showToast('Position updated accurately');
    },
    (err) => {
      // Default fallback
      appState.detectedLocation = 'Gomti Nagar, Lucknow';
      document.getElementById('current-location-val').innerText = appState.detectedLocation;
    }
  );
}

function triggerLocationSearch() {
  const newLoc = prompt('Enter breakdown address in Lucknow:', appState.detectedLocation);
  if (newLoc) {
    appState.detectedLocation = newLoc;
    document.getElementById('current-location-val').innerText = newLoc;
    showToast('Location set successfully');
  }
}

// ----------------------------------------------------
// ISSUE SELECTION & DAMAGE PHOTOS
// ----------------------------------------------------
function selectIssue(element, issueName) {
  // Remove active styling from all items
  document.querySelectorAll('.issue-item').forEach(item => item.classList.remove('active'));
  // Set active
  element.classList.add('active');
  appState.selectedIssue = issueName;
  
  // Set default pricing changes based on issue
  const billType = document.getElementById('bill-service-type');
  const billTotal = document.getElementById('bill-total-amount');
  const payBtn = document.getElementById('btn-pay');
  
  let cost = 300;
  if (issueName === 'Battery') cost = 250;
  else if (issueName === 'Engine') cost = 600;
  else if (issueName === 'Overheating') cost = 400;
  else if (issueName === 'Other') cost = 350;
  
  const gst = Math.round(cost * 0.18);
  const total = cost + gst;
  
  if (billType) billType.innerText = `${issueName} Assistance`;
  if (billTotal) billTotal.innerText = `₹${total}.00`;
  if (payBtn) payBtn.innerText = `Pay ₹${total}.00 →`;
  
  // Store amounts in state
  appState.totalBillAmount = total;
  appState.baseCost = cost;
}

function handlePhotoUpload(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    appState.uploadedPhoto = e.target.result;
    document.getElementById('photo-preview').src = e.target.result;
    document.getElementById('photo-preview-container').classList.remove('hidden');
    document.getElementById('photo-upload-label').classList.add('hidden');
    showToast('Breakdown photo attached');
  };
  reader.readAsDataURL(file);
}

function removePhoto() {
  appState.uploadedPhoto = null;
  document.getElementById('photo-file').value = '';
  document.getElementById('photo-preview-container').classList.add('hidden');
  document.getElementById('photo-upload-label').classList.remove('hidden');
}

// ----------------------------------------------------
// DISPATCH ENGINE (Radar Matchmaking)
// ----------------------------------------------------
function startDispatch() {
  goToScreen('dispatch');
  
  // Render matching cards with dynamic lists
  const list = document.getElementById('mechanics-list');
  list.innerHTML = '';
  
  appState.seededMechanics.forEach(mech => {
    // Generate markup for mechanic rating card
    const card = document.createElement('div');
    card.className = 'mechanic-card';
    card.onclick = () => selectMechanic(mech.id);
    
    card.innerHTML = `
      <div class="avatar">${mech.avatar}</div>
      <div class="details">
        <h4>${mech.name}</h4>
        <div class="rating">
          <span>⭐ ${mech.rating}</span> &bull; 
          <span class="mri-badge">MRI: ${mech.mri}%</span>
        </div>
      </div>
      <div class="distance">
        <div class="dist-val">${mech.distance} km</div>
        <div class="eta-val">${mech.eta} mins away</div>
      </div>
    `;
    list.appendChild(card);
  });
  
  // Simulating automatic dispatcher fallback in case they don't tap after 6 seconds
  appState.dispatchTimeout = setTimeout(() => {
    if (appState.currentScreen === 'dispatch') {
      showToast('Automatching nearest available mechanic...');
      selectMechanic('mech-1'); // Match Deepak Singh automatically
    }
  }, 7000);
}

function selectMechanic(mechId) {
  if (appState.dispatchTimeout) clearTimeout(appState.dispatchTimeout);
  
  const mechanic = appState.seededMechanics.find(m => m.id === mechId);
  appState.selectedMechanic = mechanic;
  
  // Update Tracking & Receipt layouts with active selections
  document.getElementById('tracking-mechanic-name').innerText = mechanic.name;
  document.getElementById('tracking-mri').innerText = `MRI: ${mechanic.mri}%`;
  document.getElementById('tracking-vehicle').innerText = mechanic.vehicle;
  document.getElementById('tracking-mechanic-avatar').innerText = mechanic.avatar;
  
  document.getElementById('rating-mechanic-title').innerText = mechanic.name;
  document.getElementById('receipt-mechanic-name').innerText = mechanic.name;
  
  goToScreen('tracking');
  showToast(`${mechanic.name} accepted request`);
}

// ----------------------------------------------------
// LIVE TRACKING & CANVAS SIMULATOR
// ----------------------------------------------------
let trackingInterval = null;
let simulatedStep = 0;

function startTrackingSimulation() {
  const canvas = document.getElementById('tracking-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);

  const start = { ...appState.selectedMechanic.startCoords };
  const end = { ...appState.userCoords };
  simulatedStep = 0;
  
  // Clear any existing intervals
  if (trackingInterval) clearInterval(trackingInterval);
  
  // Tracking clock updates
  trackingInterval = setInterval(() => {
    simulatedStep++;
    
    // Linearly interpolate mechanic pin toward user coords in 10 steps
    const t = simulatedStep / 10;
    const currentX = start.x + (end.x - start.x) * t;
    const currentY = start.y + (end.y - start.y) * t;
    
    // Draw Map Frame
    drawMapBase(ctx, rect.width, rect.height);
    
    // Draw Animated Mechanic Pin (pulsing green/violet boundary)
    ctx.fillStyle = 'rgba(139, 92, 246, 0.2)';
    ctx.beginPath();
    ctx.arc(currentX, currentY, 18 + Math.sin(simulatedStep * 0.8) * 3, 0, Math.PI * 2);
    ctx.fill();
    
    ctx.fillStyle = '#6D28D9';
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(currentX, currentY, 11, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    
    // Text inside pin
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 7px "Plus Jakarta Sans"';
    ctx.fillText('M', currentX, currentY + 0.5);
    
    // Update ETA elements dynamically
    const remainingEta = Math.max(1, appState.selectedMechanic.eta - Math.floor(simulatedStep / 2));
    document.getElementById('tracking-eta').innerText = `${remainingEta} mins`;
    
    // Progress bar updates
    const progressSegments = document.querySelectorAll('.progress-segment');
    if (simulatedStep === 4) {
      showToast(`${appState.selectedMechanic.name.split(' ')[0]} is halfway to your location.`);
    }
    
    if (simulatedStep >= 7) {
      progressSegments[2].classList.add('active'); // Repairing active
    }
    
    // Completion criteria
    if (simulatedStep >= 10) {
      clearInterval(trackingInterval);
      showToast('Repair completed by mechanic');
      setTimeout(() => {
        goToScreen('payment');
      }, 1500);
    }
  }, 3500);
}



function triggerCall() {
  showToast(`Initiating call with ${appState.selectedMechanic.name}...`);
  window.location.href = `tel:+919876543210`;
}

function cancelRequest() {
  const confirmCancel = confirm('Are you sure you want to cancel this assistance request?');
  if (confirmCancel) {
    if (trackingInterval) clearInterval(trackingInterval);
    showToast('Request cancelled successfully');
    goToScreen('home');
  }
}

// ----------------------------------------------------
// PAYMENT & BILLINGFLOW
// ----------------------------------------------------
function selectPaymentMethod(element, method) {
  document.querySelectorAll('.payment-option').forEach(opt => {
    opt.classList.remove('active');
    opt.querySelector('.pay-radio').classList.remove('active');
  });
  
  element.classList.add('active');
  element.querySelector('.pay-radio').classList.add('active');
  appState.paymentMethod = method;
}

function processPayment() {
  const btn = document.getElementById('btn-pay');
  const total = appState.totalBillAmount || 354;
  
  btn.innerText = 'Authorizing Transaction...';
  btn.disabled = true;
  
  setTimeout(() => {
    btn.innerText = 'Success!';
    showToast('Payment Settled Successfully via UPI');
    
    // Configure Rating screen inputs
    goToScreen('rating');
  }, 2000);
}

// ----------------------------------------------------
// RATING & FEEDBACK PROCESSORS
// ----------------------------------------------------
function setRating(stars) {
  appState.activeRating = stars;
  const elements = document.querySelectorAll('.star');
  
  elements.forEach((el, idx) => {
    if (idx < stars) {
      el.classList.add('selected');
    } else {
      el.classList.remove('selected');
    }
  });
}

function selectTip(element, amount) {
  document.querySelectorAll('.tip-btn').forEach(btn => btn.classList.remove('active'));
  element.classList.add('active');
  
  const customInput = document.getElementById('custom-tip-input');
  
  if (amount === 'custom') {
    customInput.classList.remove('hidden');
    customInput.focus();
    appState.activeTip = 0;
  } else {
    customInput.classList.add('hidden');
    appState.activeTip = amount;
  }
}

function updateCustomTip(val) {
  appState.activeTip = Number(val) || 0;
}

function submitRating() {
  showToast('Feedback submitted. Generating receipt...');
  
  // Calculate final paid amount (bill total + tip)
  const billTotal = appState.totalBillAmount || 354;
  const finalPaid = billTotal + appState.activeTip;
  
  // Update receipt fields
  document.getElementById('receipt-amount-paid').innerText = `₹${finalPaid}.00`;
  document.getElementById('receipt-location').innerText = appState.detectedLocation;
  
  // Generate mock dates and IDs
  const d = new Date();
  const dateStr = d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + 30);
  const expiryStr = expiryDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  
  const randomJobId = '#JOB-' + Math.floor(1000 + Math.random() * 9000);
  const randomCertId = 'OM-' + d.getFullYear() + '-' + Math.floor(1000 + Math.random() * 9000);
  
  document.getElementById('receipt-date').innerText = dateStr;
  document.getElementById('receipt-job-id').innerText = randomJobId;
  document.getElementById('warranty-id').innerText = randomCertId;
  document.getElementById('warranty-expiry').innerText = expiryStr;
  
  goToScreen('receipt');
}

// ----------------------------------------------------
// RECEIPT, OFFLINE ENGINE, AND INITIALIZERS
// ----------------------------------------------------
function simulatePDFDownload() {
  showToast('Generating Secure PDF Receipt...');
  setTimeout(() => {
    showToast('Download complete. Check file manager.');
  }, 1500);
}

function restartApp() {
  // Reset session flags
  appState.uploadedPhoto = null;
  appState.selectedMechanic = null;
  appState.activeRating = 5;
  appState.activeTip = 50;
  
  // Remove file value & upload previews
  const fileInput = document.getElementById('photo-file');
  if (fileInput) fileInput.value = '';
  document.getElementById('photo-preview-container').classList.add('hidden');
  document.getElementById('photo-upload-label').classList.remove('hidden');
  
  // Reset star highlight defaults
  setRating(5);
  
  goToScreen('home');
}

function setupOfflineSimulator() {
  const toggle = document.getElementById('offline-toggle');
  const label = document.getElementById('network-status');
  
  toggle.addEventListener('change', (e) => {
    appState.isOffline = e.target.checked;
    
    if (appState.isOffline) {
      label.innerText = 'Offline Mode';
      document.querySelector('.offline-toggle-container').style.background = '#FEE2E2';
      document.querySelector('.offline-toggle-container').style.borderColor = '#FCA5A5';
      label.style.color = '#B91C1C';
      showToast('Network Lost. Caching database onto client via Service Worker.');
    } else {
      label.innerText = 'Online Mode';
      document.querySelector('.offline-toggle-container').style.background = 'rgba(255, 255, 255, 0.9)';
      document.querySelector('.offline-toggle-container').style.borderColor = 'var(--violet-100)';
      label.style.color = 'var(--primary-violet)';
      showToast('Connection Re-established.');
    }
  });
}

// Global Toast utility
function showToast(message) {
  const toast = document.getElementById('app-toast');
  toast.innerText = message;
  toast.classList.remove('hidden');
  
  // Auto-hide after 3 seconds
  setTimeout(() => {
    toast.classList.add('hidden');
  }, 3000);
}

// ----------------------------------------------------
// MECHANIC WORKFLOW SIMULATION & OPERATIONS
// ----------------------------------------------------
function toggleGarageFields(show) {
  const container = document.getElementById('garage-details-container');
  const affInd = document.getElementById('aff-ind');
  const affGar = document.getElementById('aff-gar');
  
  const inputName = document.getElementById('garage-name');
  const inputAddr = document.getElementById('garage-address');
  
  if (show) {
    container.classList.remove('hidden');
    inputName.required = true;
    inputAddr.required = true;
    
    affGar.classList.add('active');
    affGar.style.borderColor = 'var(--primary-violet)';
    affGar.style.backgroundColor = 'var(--violet-50)';
    affGar.style.color = 'var(--primary-violet)';
    
    affInd.classList.remove('active');
    affInd.style.borderColor = 'var(--gray-200)';
    affInd.style.backgroundColor = 'var(--white)';
    affInd.style.color = 'var(--text-dark)';
  } else {
    container.classList.add('hidden');
    inputName.required = false;
    inputAddr.required = false;
    inputName.value = '';
    inputAddr.value = '';
    
    affInd.classList.add('active');
    affInd.style.borderColor = 'var(--primary-violet)';
    affInd.style.backgroundColor = 'var(--violet-50)';
    affInd.style.color = 'var(--primary-violet)';
    
    affGar.classList.remove('active');
    affGar.style.borderColor = 'var(--gray-200)';
    affGar.style.backgroundColor = 'var(--white)';
    affGar.style.color = 'var(--text-dark)';
  }
}

let bookingTimeout = null;
appState.mechanicOnline = false;

function toggleMechanicOnlineStatus(isOnline) {
  appState.mechanicOnline = isOnline;
  
  const indicator = document.getElementById('mech-status-indicator');
  const desc = document.getElementById('mech-status-desc');
  const radar = document.getElementById('online-radar-container');
  
  if (bookingTimeout) clearTimeout(bookingTimeout);
  
  if (isOnline) {
    indicator.className = 'status-indicator-box online';
    desc.innerText = 'Online & Active. Waiting for roadside breakdown bookings in Lucknow...';
    radar.classList.remove('hidden');
    showToast('You are now ONLINE. Standing by for customer requests.');
    
    // Simulate incoming booking in 5 seconds
    bookingTimeout = setTimeout(() => {
      triggerSimulatedBookingAlert();
    }, 5000);
  } else {
    indicator.className = 'status-indicator-box offline';
    desc.innerText = 'You are Offline. Go online to start receiving roadside jobs.';
    radar.classList.add('hidden');
    showToast('You are now OFFLINE. Booking alerts disabled.');
  }
}

function triggerSimulatedBookingAlert() {
  if (!appState.mechanicOnline) return;
  
  const predictedCost = "₹354.00";
  const distance = "1.4 km";
  
  // Update Alert visual texts
  document.getElementById('alert-customer-name').innerText = "Aarav Sharma";
  document.getElementById('alert-issue').innerText = "Flat tyre";
  document.getElementById('alert-distance').innerText = `${distance} away`;
  document.getElementById('alert-cost').innerText = predictedCost;
  document.getElementById('alert-location').innerText = "Faizabad Road, near Flyover";
  
  // Show the Alert overlay
  document.getElementById('booking-alert-overlay').classList.remove('hidden');
  showToast('🔊 New breakdown booking received!');
}

function declineBooking() {
  document.getElementById('booking-alert-overlay').classList.add('hidden');
  showToast('Booking request declined.');
  
  // Queue another request in 7 seconds
  if (appState.mechanicOnline) {
    bookingTimeout = setTimeout(() => {
      triggerSimulatedBookingAlert();
    }, 7000);
  }
}

function acceptBooking() {
  document.getElementById('booking-alert-overlay').classList.add('hidden');
  showToast('Request accepted. Initializing routing map.');
  
  // Setup Active Job UI customer values
  document.getElementById('job-driver-name').innerText = "Aarav Sharma";
  document.getElementById('job-driver-avatar').innerText = "AS";
  document.getElementById('job-issue-name').innerText = "Flat Tyre";
  document.getElementById('job-address-detail').innerText = "Faizabad Road, near Flyover";
  
  // Go to navigation tracking
  goToScreen('mechanic-job');
  startMechanicJobSimulation();
}

let jobCanvasInterval = null;
let jobStepIndex = 0; // 0 = Drive, 1 = Inspect, 2 = Repair
let simulatedJobNavProgress = 0;

function startMechanicJobSimulation() {
  const canvas = document.getElementById('mechanic-job-canvas');
  if (!canvas) return;
  
  const ctx = canvas.getContext('2d');
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  
  canvas.width = rect.width * dpr;
  canvas.height = rect.height * dpr;
  ctx.scale(dpr, dpr);
  
  simulatedJobNavProgress = 0;
  jobStepIndex = 0;
  
  // Reset active segments
  document.getElementById('seg-nav').className = 'progress-segment active';
  document.getElementById('seg-inspect').className = 'progress-segment';
  document.getElementById('seg-repair').className = 'progress-segment';
  document.getElementById('btn-next-job-step').innerText = "I Have Arrived →";
  document.getElementById('btn-next-job-step').className = "btn btn-primary";
  document.getElementById('job-eta').innerText = "5 mins";
  document.querySelector('#screen-mechanic-job .eta-status').innerText = "Navigating to customer location";
  
  if (jobCanvasInterval) clearInterval(jobCanvasInterval);
  
  // Mechanic garage start point -> Driver point
  const start = appState.mechanicInfo && appState.mechanicInfo.isGarage ? { x: 320, y: 80 } : { x: 50, y: 120 };
  const end = appState.userCoords; // Aarav Sharma position
  
  jobCanvasInterval = setInterval(() => {
    if (jobStepIndex === 0) {
      simulatedJobNavProgress = Math.min(10, simulatedJobNavProgress + 1);
      const t = simulatedJobNavProgress / 10;
      
      const currentX = start.x + (end.x - start.x) * t;
      const currentY = start.y + (end.y - start.y) * t;
      
      // Draw map frame
      drawMapBase(ctx, rect.width, rect.height);
      
      // Draw route line
      ctx.strokeStyle = '#8B5CF6';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(start.x, start.y);
      ctx.lineTo(currentX, currentY);
      ctx.stroke();
      
      // Pulsing Customer point (green)
      ctx.fillStyle = 'rgba(5, 150, 105, 0.2)';
      ctx.beginPath();
      ctx.arc(end.x, end.y, 16 + Math.sin(simulatedJobNavProgress) * 3, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = '#059669';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(end.x, end.y, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      
      // Moving Mechanic point (violet)
      ctx.fillStyle = 'rgba(109, 40, 217, 0.3)';
      ctx.beginPath();
      ctx.arc(currentX, currentY, 16, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = '#6D28D9';
      ctx.strokeStyle = '#FFFFFF';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(currentX, currentY, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      
      // ETA
      const remainingEta = Math.max(1, 5 - Math.floor(simulatedJobNavProgress / 2));
      document.getElementById('job-eta').innerText = `${remainingEta} mins`;
      
      if (simulatedJobNavProgress >= 10) {
        clearInterval(jobCanvasInterval);
        document.getElementById('job-eta').innerText = 'Arrived';
        showToast('You have arrived at the customer. Please inspect the breakdown.');
      }
    }
  }, 1200);
}

function advanceJobStep() {
  const btn = document.getElementById('btn-next-job-step');
  const bannerEta = document.getElementById('job-eta');
  const bannerStatus = document.querySelector('#screen-mechanic-job .eta-status');
  
  if (jobStepIndex === 0) {
    if (simulatedJobNavProgress < 10) {
      // Force completion of routing for testing
      simulatedJobNavProgress = 10;
      showToast('Arrived at customer location.');
    }
    
    jobStepIndex = 1;
    document.getElementById('seg-inspect').className = 'progress-segment active';
    bannerEta.innerText = 'Arrived';
    bannerStatus.innerText = 'Vehicle inspection in progress';
    btn.innerText = 'Start Repair Work →';
    showToast('Inspection started.');
  } else if (jobStepIndex === 1) {
    jobStepIndex = 2;
    document.getElementById('seg-repair').className = 'progress-segment active';
    bannerEta.innerText = 'Repairing';
    bannerStatus.innerText = 'Fixing flat tyre...';
    btn.innerText = 'Complete Repair & Bill →';
    showToast('Repair work started.');
  } else if (jobStepIndex === 2) {
    if (jobCanvasInterval) clearInterval(jobCanvasInterval);
    
    // Configure QR payment card values
    document.getElementById('qr-driver-name').innerText = "Aarav Sharma";
    document.getElementById('qr-issue-type').innerText = "Flat Tyre Assistance";
    document.getElementById('qr-total-amount').innerText = "₹354.00";
    
    // Generate code
    generateUPIQRCode("354.00", "Aarav Sharma");
    goToScreen('mechanic-qr');
  }
}

function triggerCallCustomer() {
  showToast('Initiating call with customer Aarav Sharma...');
  window.location.href = `tel:+919876543210`;
}

function generateUPIQRCode(amount, customerName) {
  const container = document.getElementById('qr-code-container');
  container.innerHTML = `
    <svg viewBox="0 0 160 160" width="160" height="160" xmlns="http://www.w3.org/2000/svg">
      <rect width="160" height="160" fill="#FFFFFF" rx="12"/>
      
      <!-- Finder Patterns (Top Left, Top Right, Bottom Left) -->
      <rect x="15" y="15" width="30" height="30" fill="#1E1B4B" rx="4"/>
      <rect x="21" y="21" width="18" height="18" fill="#FFFFFF" rx="2"/>
      <rect x="25" y="25" width="10" height="10" fill="#6D28D9" rx="1"/>
      
      <rect x="115" y="15" width="30" height="30" fill="#1E1B4B" rx="4"/>
      <rect x="121" y="21" width="18" height="18" fill="#FFFFFF" rx="2"/>
      <rect x="125" y="25" width="10" height="10" fill="#6D28D9" rx="1"/>
      
      <rect x="15" y="115" width="30" height="30" fill="#1E1B4B" rx="4"/>
      <rect x="21" y="121" width="18" height="18" fill="#FFFFFF" rx="2"/>
      <rect x="25" y="125" width="10" height="10" fill="#6D28D9" rx="1"/>
      
      <!-- Alignment Pattern Bottom Right -->
      <rect x="120" y="120" width="15" height="15" fill="#6D28D9" rx="2"/>
      <rect x="124" y="124" width="7" height="7" fill="#FFFFFF" rx="1"/>
      <rect x="126" y="126" width="3" height="3" fill="#1E1B4B"/>
      
      <!-- Mock QR grid bits -->
      <g fill="#6D28D9">
        <rect x="55" y="15" width="10" height="5"/>
        <rect x="75" y="15" width="15" height="10"/>
        <rect x="100" y="20" width="5" height="15"/>
        
        <rect x="15" y="55" width="10" height="10"/>
        <rect x="35" y="60" width="15" height="5"/>
        <rect x="55" y="35" width="20" height="10"/>
        <rect x="80" y="45" width="10" height="15"/>
        <rect x="95" y="45" width="15" height="10"/>
        
        <rect x="15" y="80" width="15" height="10"/>
        <rect x="40" y="80" width="20" height="5"/>
        <rect x="65" y="70" width="10" height="20"/>
        <rect x="85" y="75" width="20" height="15"/>
        <rect x="110" y="65" width="10" height="10"/>
        <rect x="125" y="55" width="20" height="15"/>
        <rect x="130" y="80" width="15" height="10"/>
        
        <rect x="55" y="100" width="15" height="10"/>
        <rect x="80" y="105" width="10" height="20"/>
        <rect x="95" y="100" width="15" height="15"/>
        
        <rect x="55" y="120" width="10" height="20"/>
        <rect x="70" y="130" width="20" height="10"/>
        <rect x="95" y="130" width="15" height="15"/>
      </g>
      
      <!-- Center UPI Emblem -->
      <rect x="65" y="65" width="30" height="30" fill="#FFFFFF" rx="6" stroke="#EDE9FE" stroke-width="1.5"/>
      <text x="80" y="84" font-family="system-ui, sans-serif" font-weight="900" font-size="8" fill="#6D28D9" text-anchor="middle">UPI</text>
    </svg>
  `;
}

function confirmMechanicPayment() {
  showToast('Settlement Confirmed! Payment Received.');
  setTimeout(() => {
    // Reset toggle
    const toggle = document.getElementById('mech-status-toggle');
    if (toggle) toggle.checked = false;
    toggleMechanicOnlineStatus(false);
    
    goToScreen('mechanic-home');
  }, 1200);
}

// Service Worker Registration
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js')
      .then(reg => console.log('Service Worker registered successfully:', reg.scope))
      .catch(err => console.log('Service Worker registration failed:', err));
  });
}

